# KDT Ledger Quest — Full Source Starter

An interactive FastAPI + HTML/CSS/JavaScript prototype for the Ledger Open Track on **XRPL Testnet**.

## Features
- Gaming quest arena (local demo XP, no on-chain issuance)
- XRPL Testnet RPC health and validated ledger state
- Public wallet balance lookup
- Unsigned XRP payment preparation with source account sequence, live fee, last-ledger expiry and optional destination tag
- External Ledger-signing workflow: signed transaction blob submission (opt-in)
- Transaction validation and XRPL Testnet explorer link
- No secret key handling; no mnemonic input
- Unit/API tests for validation and safe defaults

## Windows setup
1. Install Python 3.11+ and ensure Python is on PATH.
2. Extract this ZIP and open a terminal in the `KDT_Ledger_Quest_Full` folder.
3. Run:

```powershell
py -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
Copy-Item .env.example .env
python -m uvicorn app.main:app --reload
```

4. Open http://127.0.0.1:8000/ in your browser.
5. API docs: http://127.0.0.1:8000/docs

If PowerShell blocks activation, use `.venv\Scripts\python.exe -m pip install -r requirements.txt` and `.venv\Scripts\python.exe -m uvicorn app.main:app --reload` without activating.

## macOS / Linux
```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
cp .env.example .env
python -m uvicorn app.main:app --reload
```

## Tests
```bash
python -m pytest -q
```

## Testnet transaction flow
1. Obtain a funded XRPL **Testnet** account using the official XRPL Testnet faucet. Do not use a mainnet wallet or send real funds.
2. Enter public source/destination addresses and a small XRP amount.
3. Click **Generate unsigned Testnet payment**. The server reads account sequence, current fee and validated ledger index from the public Testnet RPC.
4. Use a **separately installed, compatible Ledger device-signing integration** to review and sign the exact transaction. This project does **not** implement USB/HID Ledger pairing or direct device signing. Confirm device app/SDK support independently.
5. For explicit broadcasting, set `ALLOW_TESTNET_SUBMISSION=true` in `.env`, restart server, and paste only the signed `tx_blob` hex.
6. Check the resulting transaction hash via **Verify transaction**. Settlement requires `validated: true` and `result: tesSUCCESS`; initial submit response alone is not finality.

## Security and limitations
- The API does not request, store, or accept secret keys or recovery phrases. **Never paste those into this dashboard.**
- All transactions use public XRPL Testnet RPC by default; there is no production-grade RPC authentication, rate limiting, or deployment hardening.
- `ALLOW_TESTNET_SUBMISSION` defaults to `false`. Do not enable on a public server without authentication and authorization.
- The prepared payment cap is 100 XRP (Testnet), but fee/reserve and destination safety require user/device review.
- The server does not independently decode or inspect a signed blob before submission; submit only after trusted Ledger verification.
- XRPL's `tesSUCCESS` on initial submission does not guarantee ledger validation.
- NFT marketplace, Ledger device pairing, and real on-chain game rewards are future integrations, not shipped features.
- Requires internet access to reach the XRPL Testnet endpoint. Health and network calls fail gracefully when offline.

## Suggested hackathon extension
Integrate Ledger's currently supported XRP device signing SDK in a separate client, enforce hardware-displayed recipient/amount confirmation, implement NFT flows supported by the device signer, add server authentication, and demonstrate a **validated Testnet transaction** with a transaction hash.
