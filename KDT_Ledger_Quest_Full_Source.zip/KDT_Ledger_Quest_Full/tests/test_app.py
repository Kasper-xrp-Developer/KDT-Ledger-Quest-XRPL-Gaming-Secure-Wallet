import os
os.environ['ALLOW_TESTNET_SUBMISSION'] = 'false'
from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_home():
    r = client.get('/')
    assert r.status_code == 200
    assert 'KDT LEDGER QUEST' in r.text

def test_config():
    r = client.get('/api/config')
    assert r.status_code == 200
    assert r.json()['network'] == 'XRPL Testnet'

def test_reject_invalid_address():
    assert client.get('/api/account/not-an-address').status_code == 422

def test_reject_invalid_payment():
    r = client.post('/api/payment/prepare', json={'source':'invalid','destination':'invalid','drops':1})
    assert r.status_code == 422

def test_submit_disabled_by_default():
    r = client.post('/api/transaction/submit', json={'tx_blob':'A'*20})
    assert r.status_code == 403

def test_invalid_hash():
    assert client.get('/api/transaction/bad').status_code == 422
