"""KDT Ledger Quest: noncustodial XRPL Testnet companion API.
No private keys, seed phrases, or Ledger signing secrets are accepted.
"""
import os
import re
from pathlib import Path
from typing import Optional

import httpx
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

load_dotenv()
BASE = Path(__file__).resolve().parent
RPC = os.getenv("XRPL_RPC_URL", "https://s.altnet.rippletest.net:51234/")
EXPLORER = os.getenv("XRPL_EXPLORER", "https://testnet.xrpl.org/transactions/")
SUBMIT_ENABLED = os.getenv("ALLOW_TESTNET_SUBMISSION", "false").lower() == "true"
ADDRESS = re.compile(r"^r[1-9A-HJ-NP-Za-km-z]{24,34}$")
HEX = re.compile(r"^[0-9a-fA-F]+$")
app = FastAPI(title="KDT Ledger Quest", version="1.0.0")
app.mount("/static", StaticFiles(directory=BASE / "static"), name="static")

class AccountInput(BaseModel):
    address: str

class PaymentDraft(BaseModel):
    source: str
    destination: str
    drops: int = Field(ge=1, le=100_000_000)
    destination_tag: Optional[int] = Field(default=None, ge=0, le=4294967295)

class SignedBlob(BaseModel):
    tx_blob: str = Field(min_length=20, max_length=65536)

async def rpc(method: str, **params):
    try:
        async with httpx.AsyncClient(timeout=12) as client:
            response = await client.post(RPC, json={"method": method, "params": [params]})
            response.raise_for_status()
            payload = response.json()
        result = payload.get("result", {})
        if result.get("status") == "error" or result.get("error"):
            raise HTTPException(status_code=502, detail=result.get("error_message", result.get("error", "XRPL error")))
        return result
    except httpx.HTTPError as exc:
        raise HTTPException(status_code=503, detail=f"XRPL RPC unavailable: {type(exc).__name__}") from exc

@app.get("/")
def home():
    return FileResponse(BASE / "static" / "index.html")

@app.get("/api/config")
def config():
    return {"network": "XRPL Testnet", "explorer": EXPLORER, "submission_enabled": SUBMIT_ENABLED, "ledger_signing": "external"}

@app.get("/api/health")
async def health():
    result = await rpc("server_info")
    info = result.get("info", {})
    return {"ok": True, "network": "XRPL Testnet", "server_state": info.get("server_state", "unknown"), "validated_ledger": info.get("validated_ledger", {}).get("seq")}

@app.get("/api/account/{address}")
async def account(address: str):
    if not ADDRESS.fullmatch(address):
        raise HTTPException(status_code=422, detail="Invalid XRPL classic address format")
    try:
        result = await rpc("account_info", account=address, ledger_index="validated")
        data = result.get("account_data", {})
        return {"address": address, "balance_drops": data.get("Balance", "0"), "sequence": data.get("Sequence"), "ledger_index": result.get("ledger_index")}
    except HTTPException as exc:
        if "actNotFound" in str(exc.detail):
            return {"address": address, "balance_drops": "0", "sequence": None, "unfunded": True}
        raise

@app.post("/api/payment/prepare")
async def prepare(payment: PaymentDraft):
    if not ADDRESS.fullmatch(payment.source) or not ADDRESS.fullmatch(payment.destination):
        raise HTTPException(status_code=422, detail="Invalid XRPL classic address")
    if payment.source == payment.destination:
        raise HTTPException(status_code=422, detail="Source and destination must differ")
    account_data = await rpc("account_info", account=payment.source, ledger_index="validated")
    sequence = account_data.get("account_data", {}).get("Sequence")
    if sequence is None:
        raise HTTPException(status_code=422, detail="Source account is not funded")
    ledger = await rpc("ledger", ledger_index="validated")
    index = ledger.get("ledger_index") or ledger.get("ledger", {}).get("ledger_index")
    if index is None:
        raise HTTPException(status_code=503, detail="Validated ledger index unavailable")
    fee = await rpc("fee")
    fee_drops = fee.get("drops", {}).get("open_ledger_fee", "12")
    tx = {"TransactionType": "Payment", "Account": payment.source, "Destination": payment.destination,
          "Amount": str(payment.drops), "Fee": str(fee_drops), "Sequence": sequence,
          "LastLedgerSequence": int(index) + 20}
    if payment.destination_tag is not None:
        tx["DestinationTag"] = payment.destination_tag
    return {"unsigned_transaction": tx, "warning": "Review address, amount and fee on trusted device/software before signing. Never share your seed phrase.", "signing": "Sign externally with Ledger-compatible XRP software; submit only the signed tx_blob."}

@app.post("/api/transaction/submit")
async def submit(body: SignedBlob):
    if not SUBMIT_ENABLED:
        raise HTTPException(status_code=403, detail="Testnet submission disabled. Set ALLOW_TESTNET_SUBMISSION=true")
    if len(body.tx_blob) % 2 or not HEX.fullmatch(body.tx_blob):
        raise HTTPException(status_code=422, detail="tx_blob must be even-length hexadecimal")
    result = await rpc("submit", tx_blob=body.tx_blob)
    tx_hash = result.get("tx_json", {}).get("hash") or result.get("tx_json", {}).get("hash")
    return {"engine_result": result.get("engine_result"), "tx_hash": tx_hash,
            "explorer": EXPLORER + tx_hash if tx_hash else None,
            "note": "Submission is not settlement; confirm validated=true via transaction lookup."}

@app.get("/api/transaction/{tx_hash}")
async def transaction(tx_hash: str):
    if len(tx_hash) != 64 or not HEX.fullmatch(tx_hash):
        raise HTTPException(status_code=422, detail="Expected 64-character transaction hash")
    result = await rpc("tx", transaction=tx_hash, binary=False)
    return {"hash": tx_hash, "validated": result.get("validated", False),
            "result": result.get("meta", {}).get("TransactionResult"), "ledger_index": result.get("ledger_index"),
            "explorer": EXPLORER + tx_hash}
